

var blc = document.getElementById("blcal");

var hed = document.getElementById("hed");




blc.addEventListener("click",function(){
	blc.style.display = "none";
	hed.innerHTML = "Weby na seznamu dezinfo & fake news jsou zablokov&aacute;ny";
	hed.style.color = "red";
	chrome.storage.local.set({notifs: "true"}, function() {
	   console.log('Value is set to ');
	});
});

chrome.storage.local.get(['notifs'], function(resultss) { 
		  if(resultss.notifs == "true"){
			  blc.style.display = "none";
			  hed.innerHTML = "Weby na seznamu dezinfo & fake news jsou zablokov&aacute;ny";
			  hed.style.color = "red";
		  } else {
			  blc.style.display = "block";
		  }
		 
});



