


function getDomain(url, subdomain) {
    subdomain = subdomain || false;

    url = url.replace(/(https?:\/\/)?(www.)?/i, '');

    if (!subdomain) {
        url = url.split('.');

        url = url.slice(url.length - 2).join('.');
    }

    if (url.indexOf('/') !== -1) {
        return url.split('/')[0];
    }

    return url;
}


function trimernumber(llb){
	var asd = llb;
	var xyz = asd.split(".");

	if(xyz[0] == "www"){
		var mm = asd.split("www.");
		return mm[1];
	   }
	   else{
		   return asd;
	   }
	
}





chrome.storage.local.get(['notifs'], function(resultss) { 
		  if(resultss.notifs == "true"){
			  chrome.storage.local.get(['key'], function(result) {
						  console.log(result.key[0]);
						  console.log(result.key.length);
						  var arss = result.key;
						  for(var i=0; i < arss.length; i++){
							  if(trimernumber(location.host) == result.key[i]){
								  location.replace("https://www.konspiratori.sk/zoznam-stranok.php");
								/*  chrome.storage.local.set({retd: getDomain(location.host)}, function() {
									  console.log('Value is set to ');
									});*/
							  }
						  }
						  
				});
		  }
		  else
		  {
			  chrome.storage.local.get(['key'], function(result) {
						  console.log(result.key[0]);
						  console.log(result.key.length);
						  var arss = result.key;
						  for(var i=0; i < arss.length; i++){
							  if(trimernumber(location.host) == result.key[i]){
								  //location.replace("https://www.konspiratori.sk/");
								/*  chrome.storage.local.set({retd: getDomain(location.host)}, function() {
									  console.log('Value is set to ');
									});*/
								  
								  var pga = document.getElementsByTagName("body");
								  pga[0].insertAdjacentHTML('beforeend', '<div id="datacont" style="border-radius: 40px; height: 100px; justify-content: center; background: red; width: 90%; cursor: pointer; padding: 30px; position: fixed; font-size: 25px; text-align: center; color: #ffffff; top: 25px; left: 50px; z-index: 99999; box-shadow: 0px 0px 10px 1px;">Právě se nacházíte na webové stránce, která je ve veřejné databázi webových stránek s sporným, neseriózním, klamavým, podvodným, konspiračním a nebo propagandistickým obsahem. <br><br>Seznam sporných webů najdete na <a style="color: #09671d !important;" href="https://www.konspiratori.sk/">konspiratori.sk</a></div>');

							  }
						  }
						  
				});
		  }
		 
});



var datast = trimernumber(location.host);
chrome.storage.local.set({retd: datast}, function() {
	  console.log('Value is set to ');
});







console.log(getDomain(location.host));
